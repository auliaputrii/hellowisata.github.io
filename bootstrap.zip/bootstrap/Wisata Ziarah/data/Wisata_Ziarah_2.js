var json_Wisata_Ziarah_2 = {
"type": "FeatureCollection",
"name": "Wisata_Ziarah_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OBJECTID": "1", "No_": 1.0, "Nama_Wisat": "Makam Sunan Amangkurat Agung", "X": 289683.0, "Y": 9234409.0, "Lokasi": "Dusun Pakuncen, Desa Pesarean, Kecamatan Adiwerna, Kabupaten Tegal", "Tiket_Masu": "Gratis", "Tarif_Park": "Gratis", "Jam_Operas": "Jam Operasional Pukul 08.00-16.00 WIB", "Fasilitas": "Toilet, Masjid", "Foto": "<img src='C:\\Users\\Putri\\Downloads\\BISMILLAH\\TA\\TA\\amangkurat.jpg'>", "Sumber": "Gallery Tegal" }, "geometry": { "type": "Point", "coordinates": [ 109.096489997527215, -6.922394074564664 ] } },
{ "type": "Feature", "properties": { "OBJECTID": "2", "No_": 2.0, "Nama_Wisat": "Makam Ki Ageng Anggawana", "X": 291475.0, "Y": 9231275.0, "Lokasi": "Desa Kalisoka, Kecamatan Dukuhwaru, Kabupaten Tegal", "Tiket_Masu": "Gratis", "Tarif_Park": "Gratis", "Jam_Operas": "Jam Operasional Pukul 08.00-16.00 WIB", "Fasilitas": "Toilet, Masjid", "Foto": "<img src='C:\\Users\\Putri\\Downloads\\BISMILLAH\\TA\\TA\\anggawana.jpg'>", "Sumber": "Budaya Tegal" }, "geometry": { "type": "Point", "coordinates": [ 109.108339084178695, -6.951988628313987 ] } },
{ "type": "Feature", "properties": { "OBJECTID": "3", "No_": 3.0, "Nama_Wisat": "Makam Pangeran Purbaya", "X": 291637.0, "Y": 9230777.0, "Lokasi": "Desa Kalisoka, Kecamatan Dukuhwaru, Kabupaten Tegal", "Tiket_Masu": "Gratis", "Tarif_Park": "Gratis", "Jam_Operas": "Jam Operasional Pukul 08.00-16.00 WIB", "Fasilitas": "Toilet, Masjid", "Foto": "<img src='C:\\Users\\Putri\\Downloads\\BISMILLAH\\TA\\TA\\purbaya.jpg'>", "Sumber": "Wisata Tegal" }, "geometry": { "type": "Point", "coordinates": [ 109.114037737222361, -6.955301625358034 ] } }
]
}
