var json_Wisata_Buru_2 = {
"type": "FeatureCollection",
"name": "Wisata_Buru_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OBJECTID": "1", "No_": 1.0, "Nama_Wisat": "Objek Wisata Pemandian Air Panas Guci", "X": 297303.84, "Y": 9203905.11, "Lokasi": "Desa Guci, Kecamatan Bumijawa, Kabupaten Tegal", "Tiket_Masu": "Tiket masuk hari biasa (Senin-Jumat) Dewasa Rp. 5.000 & Anak-anak Rp. 4.500. Sedangkan tiket masuk hari libur (Sabtu-Minggu) Dewasa Rp. 7.000 & Anak-anak Rp. 6.500. *Nb : Biaya tersebut masih harus ditambah dengan biaya asuransi jasa raharja.", "Tarif_Park": "Tarif Parkir Motor Rp. 3.000 & Tarif Parkir Mobil Rp. 10.000", "Jam_Operas": "Jam Operasional Pukul 06.00-21.00 WIB", "Fasilitas": "Kolam renang (waterboom), trek jalan kaki, pancuran air panas, persewaan kuda tunggang, fasilitas outbound, toilet umum, musholla, tempat makan dan tempat penginapan (Hotel Duta Wisata, Hotel Guci-Ku, Hotel Sankita, Wisma\/Villa, dan lain-lain)", "Foto": "<img src='C:\\Users\\Putri\\Downloads\\BISMILLAH\\TA\\TA\\guci.jpg'>", "Sumber": "@infotegal" }, "geometry": { "type": "Point", "coordinates": [ 109.172426972063562, -7.204639160197804 ] } }
]
}
