var json_Wisata_Pertanian_2 = {
"type": "FeatureCollection",
"name": "Wisata_Pertanian_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OBJECTID": "1", "No_": 2.0, "Nama_Wisat": "PG Pangkah", "X": 297664.0, "Y": 9228555.0, "Lokasi": "Desa Pangkah, Kecamatan Pangkah, Kabupaten Tegal", "Tiket_Masu": "Tiket Masuk (Senin-Minggu) Rp. 5.000", "Tarif_Park": "Tarif Parkir Motor Rp. 3.000 & Tarif Parkir Mobil Rp. 5.000", "Jam_Operas": "Jam Operasional Pukul 08.00-17.00 WIB", "Fasilitas": "Loko antik, spot foto, mushola, toilet, warung-warung makan.", "Foto": "<img src='C:\\Users\\Putri\\Downloads\\BISMILLAH\\TA\\TA\\pangkah.jpg'>", "Sumber": "@siardhi20" }, "geometry": { "type": "Point", "coordinates": [ 109.168492880186335, -6.975605593827739 ] } }
]
}
